## 怎么分享我的插件？
Fork [yapi](https://github.com/YMFE/yapi), 然后修改 docs/documents/plugin-list.md, 修改完成后请 Pull-Request.

## 插件列表

* [dingding](https://github.com/zgs225/yapi-plugin-dding) 钉钉机器人推送插件
* [qsso](https://github.com/ymfe/yapi-plugin-qsso) sso 第三方登录
* [import-rap](https://github.com/wxxcarl/yapi-plugin-import-rap) 从rap中导入项目
* [export-docx-data](https://github.com/inceptiongt/Yapi-plugin-export-docx-data) 数据导出docx文档
* [import-swagger-customize](https://github.com/follow-my-heart/yapi-plugin-import-swagger-customize) 导入指定swagger接口
* [autotest](https://github.com/duicym/yapi-plugin-autotest) 定时自动测试发送钉钉插件
