module.exports = {
    server: true,
    client: true
  }